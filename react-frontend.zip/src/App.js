import './App.css';
import {BrowserRouter as Router, Route, Switch} from 'react-router-dom'
import FooterComponent from './components/FooterComponent';
import HeaderComponent from './components/HeaderComponent';
import ListTaskComponent from './components/ListTaskComponent';
import CreateTaskComponent from './components/CreateTaskComponent';
import UpdateTaskComponent from './components/UpdateTaskComponent';

function App() {
  return (
    <div>
      <Router>
         <HeaderComponent />
           <div className="container">
             <Switch> 
               <Route path="/" exact component = {ListTaskComponent}></Route>
               <Route path="/tasks" component = {ListTaskComponent}></Route>
               //step 1
               <Route path="/add-task/:id" component = {CreateTaskComponent}></Route>
               {/*<Route path="/update-task/:id" component = {UpdateTaskComponent}></Route>*/}
             </Switch>
           </div>
         <FooterComponent />
     </Router>
   </div>
  );
}

export default App;
