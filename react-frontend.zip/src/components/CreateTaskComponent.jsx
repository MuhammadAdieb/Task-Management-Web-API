import React, { Component } from 'react';
import TaskService from '../services/TaskService';

class CreateTaskComponent extends Component {
    constructor(props){
        super(props)
        //step 2
        this.state = {
            id: this.props.match.params.id,
            taskName: '',
            taskCompletion: ''
        }
        this.changeTaskNameHandler=this.changeTaskNameHandler.bind(this);
        this.changeTaskCompletionHandler=this.changeTaskCompletionHandler.bind(this);
        this.saveOrUpdateTask=this.saveOrUpdateTask.bind(this);
    }
    //step 3
    componentDidMount(){
        //step 4
        if(this.state.id === '_add'){
            return
        }else{
            TaskService.getTaskById(this.state.id).then((res) => {
                let task =res.data;
                this.setState({taskName: task.taskName,
                taskCompletion: task.taskCompletion
               });
            });
        }
    }
    saveOrUpdateTask= (e) => {
        e.preventDefault();
        let task = {taskName: this.state.taskName, taskCompletion: this.state.taskCompletion};
        console.log('task =>' + JSON.stringify(task));
        //step 5
        if(this.state.id === '_add'){
            TaskService.createTask(task).then(res => {
                this.props.history.push('/tasks');
            });
        }else{
            TaskService.updateTask(task,this.state.id).then((res) => {
                this.props.history.push('/tasks');
            });
       }
    }
    changeTaskNameHandler=(event) => {
        this.setState({taskName: event.target.value});
    }
    changeTaskCompletionHandler=(event) =>{
        this.setState({taskCompletion: event.target.value});
    }

    cancel(){
        this.props.history.push('/tasks');
    }

    getTitle(){
        if(this.state.id === '_add'){
            return <h3 className="text-center">Add Task</h3>
        }else{
            return <h3 className="text-center">Update Task</h3>
        }
    }
    render() {
        return (
            <div>
                <div className="container">
                    <div className="row">
                       <div className="card col-md-6 offset-md-3 offset-md-3">
                          {
                            this.getTitle()
                          }
                          <div className="card-body">
                             <form>
                                 <div className="form-group">
                                      <label> Task Name:</label>
                                      <input placeholder="Task Name" name="taskName" className="form-control"
                                         value={this.state.taskName} onChange={this.changeTaskNameHandler}/>
                                 </div>
                                 <div className="form-group">
                                      <label> Task Completion:</label>
                                      <input placeholder="Task Completion" name="taskCompletion" className="form-control"
                                         value={this.state.taskCompletion} onChange={this.changeTaskCompletionHandler}/>
                                 </div>
                                 <button className="btn btn-success" onClick={this.saveOrUpdateTask}>Save</button>
                                 <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft:"10px"}}>Cancel</button>
                             </form>
                          </div>
                        </div> 
                    </div>
                </div>
            </div>
        );
    }
}

export default CreateTaskComponent;