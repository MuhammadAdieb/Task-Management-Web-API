package com.example.springboot1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringboottaskmanageBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringboottaskmanageBackendApplication.class, args);
	}

}
