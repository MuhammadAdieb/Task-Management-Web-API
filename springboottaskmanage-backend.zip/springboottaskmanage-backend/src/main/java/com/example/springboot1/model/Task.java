package com.example.springboot1.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="tasks")
public class Task {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column(name="task_name")
	private String taskName;
	
	@Column(name="task_completion")
	private String taskCompletion;
	
	public Task() {
		
	}
	
	public Task(String taskName, String taskCompletion) {
		super();
		this.taskName = taskName;
		this.taskCompletion = taskCompletion;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public String getTaskCompletion() {
		return taskCompletion;
	}
	public void setTaskCompletion(String taskCompletion) {
		this.taskCompletion = taskCompletion;
	}
	
	
}
